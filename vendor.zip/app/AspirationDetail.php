<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AspirationDetail extends Model
{
    //
}
