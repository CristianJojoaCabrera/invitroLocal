<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>InVitro</title>

    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

</head>

<body class="gray-bg">

<div class="middle-box text-center loginscreen animated fadeInDown">
    <div>
        <div>
            <img src="<?php echo e(asset('img/logo.png')); ?>" class="img-responsive">
        </div>
        <h3>Bienvenido a InVitro</h3>
        <p>Iniciar Sesión</p>
        <form class="m-t" role="form" action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <input type="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="Usuario" required="" value="<?php echo e(old('email')); ?>">
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <input type="password" name="password" class="form-control" placeholder="Contraseña" required="">
                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-primary block full-width m-b">Iniciar</button>

            <a href="<?php echo e(route('password.request')); ?>"><small>¿Olvidó su contraseña?</small></a>
            <p class="text-muted text-center"><small>¿No tiene una cuenta?</small></p>
            <a class="btn btn-sm btn-white btn-block" href="register.html">Crear una cuenta</a>
        </form>
        <p class="m-t"> <small>&copy; 2018</small> </p>
    </div>
</div>

<!-- Mainly scripts -->
<script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

</body>

</html>
