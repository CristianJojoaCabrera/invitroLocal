<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('css'); ?>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Diagnóstico</h2>
            <ol class="breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                </li>
                <li class="active">
                    <strong>Diagnóstico</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2">

        </div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Órdenes de Producción</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li><a href="#">Config option 1</a>
                                </li>
                                <li><a href="#">Config option 2</a>
                                </li>
                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover dataTables-example" >
                                <thead>
                                    <tr>
                                        <th>Tipo Id.</th>
                                        <th>Identificación</th>
                                        <th>Razón Social</th>
                                        <th>Dirección</th>
                                        <th>Teléfono</th>
                                        <th>Celular</th>
                                        <th>Correo</th>
                                        <th>Contacto</th>
                                        <th>Cargo</th>
                                        <th>Ciudad</th>
                                        <th>Pais</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $productionOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productionOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($productionOrder->identification_type); ?></td>
                                            <td><?php echo e($productionOrder->identification_number); ?></td>
                                            <td><?php echo e($productionOrder->bussiness_name); ?></td>
                                            <td><?php echo e($productionOrder->address); ?></td>
                                            <td><?php echo e($productionOrder->phone); ?></td>
                                            <td><?php echo e($productionOrder->cellphone); ?></td>
                                            <td><?php echo e($productionOrder->email); ?></td>
                                            <td><?php echo e($productionOrder->contact); ?></td>
                                            <td><?php echo e($productionOrder->position); ?></td>
                                            <td><?php echo e($productionOrder->city); ?></td>
                                            <td><?php echo e($productionOrder->country); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>