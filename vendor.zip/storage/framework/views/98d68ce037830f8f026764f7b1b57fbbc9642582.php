<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content'); ?>
    <div class="ibox float-e-margins">
        <div class="ibox-content" id="ibox-content">
            <div class="wrapper wrapper-content">
                <div class="row">
                    <img src="img/invitro_logo.png" class="img-fluid" alt="invitro_logo" style="width:100%">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>