<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <?php echo $__env->make('app.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <body class="fixed-navigation">
        <div id="wrapper">
            <?php echo $__env->make('app.vertical-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div id="page-wrapper" class="gray-bg">
                <div class="row border-bottom">
                    <?php echo $__env->make('app.horizontal-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="wrapper wrapper-content">
                    <div class="animated fadeInRight">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
                <?php echo $__env->make('app.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('app.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('javascript'); ?>
    </body>
</html>