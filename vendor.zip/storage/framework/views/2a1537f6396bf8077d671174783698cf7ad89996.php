<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Cliente</h2>
            <ol class="breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                </li>
                <li>
                    <a href="index.html">Maestros</a>
                </li>
                <li class="active">
                    <strong>Clientes</strong>
                </li>
            </ol>
        </div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">

                <div class="tabs-container">
                    <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#tab-1">Clientes</a></li>
                        <li class=""><a data-toggle="tab" href="#tab-2">Nuevo</a></li>
                    </ul>
                    <div class="tab-content">
                        <div id="tab-1" class="tab-pane active">
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover dataTables-example" >
                                        <thead>
                                        <tr>
                                            <th>Tipo Id.</th>
                                            <th>Número Id.</th>
                                            <th>Razón Social</th>
                                            <th>Dirección</th>
                                            <th>Teléfono</th>
                                            <th>Móvil</th>
                                            <th>Correo</th>
                                            <th>Ciudad</th>
                                            <th>País</th>
                                            <th>Referido</th>
                                            <th>Cupo</th>
                                            <th>Plazo</th>
                                            <th>Editar</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr class="gradeX">
                                            <td>1</td>
                                            <td>Trident</td>
                                            <td>Internet
                                                Explorer 4.0
                                            </td>
                                            <td>Win 95+</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center"></td>
                                            <td class="center">
                                                <button type="button" class="btn btn-xs btn-warning">
                                                    <i class="fa fa-edit"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="gradeC">
                                            <td>2</td>
                                            <td>Trident</td>
                                            <td>Internet
                                                Explorer 5.0
                                            </td>
                                            <td>Win 95+</td>
                                            <td class="center">5</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center"></td>
                                            <td class="center">
                                                <button type="button" class="btn btn-xs btn-warning">
                                                    <i class="fa fa-edit"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="gradeA">
                                            <td>3</td>
                                            <td>Trident</td>
                                            <td>Internet
                                                Explorer 5.5
                                            </td>
                                            <td>Win 95+</td>
                                            <td class="center">5</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center"></td>
                                            <td class="center">
                                                <button type="button" class="btn btn-xs btn-warning">
                                                    <i class="fa fa-edit"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="gradeA">
                                            <td>4</td>
                                            <td>Trident</td>
                                            <td>Internet
                                                Explorer 6
                                            </td>
                                            <td>Win 98+</td>
                                            <td class="center">6</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center"></td>
                                            <td class="center">
                                                <button type="button" class="btn btn-xs btn-warning">
                                                    <i class="fa fa-edit"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="gradeA">
                                            <td>5</td>
                                            <td>Trident</td>
                                            <td>Internet Explorer 7</td>
                                            <td>Win XP SP2+</td>
                                            <td class="center">7</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center"></td>
                                            <td class="center">
                                                <button type="button" class="btn btn-xs btn-warning">
                                                    <i class="fa fa-edit"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="gradeA">
                                            <td>6</td>
                                            <td>Trident</td>
                                            <td>AOL browser (AOL desktop)</td>
                                            <td>Win XP</td>
                                            <td class="center">6</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center"></td>
                                            <td class="center">
                                                <button type="button" class="btn btn-xs btn-warning">
                                                    <i class="fa fa-edit"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="gradeA">
                                            <td>7</td>
                                            <td>Gecko</td>
                                            <td>Firefox 1.0</td>
                                            <td>Win 98+ / OSX.2+</td>
                                            <td class="center">1.7</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center"></td>
                                            <td class="center">
                                                <button type="button" class="btn btn-xs btn-warning">
                                                    <i class="fa fa-edit"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="gradeA">
                                            <td>8</td>
                                            <td>Gecko</td>
                                            <td>Firefox 1.5</td>
                                            <td>Win 98+ / OSX.2+</td>
                                            <td class="center">1</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center"></td>
                                            <td class="center">
                                                <button type="button" class="btn btn-xs btn-warning">
                                                    <i class="fa fa-edit"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="gradeA">
                                            <td>9</td>
                                            <td>Gecko</td>
                                            <td>Firefox 2.0</td>
                                            <td>Win 98+ / OSX.2+</td>
                                            <td class="center">8</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center"></td>
                                            <td class="center">
                                                <button type="button" class="btn btn-xs btn-warning">
                                                    <i class="fa fa-edit"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="gradeA">
                                            <td>10</td>
                                            <td>Gecko</td>
                                            <td>Firefox 3.0</td>
                                            <td>Win 2k+ / OSX.3+</td>
                                            <td class="center">4</td>
                                            <td class="center">9</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center"></td>
                                            <td class="center">
                                                <button type="button" class="btn btn-xs btn-warning">
                                                    <i class="fa fa-edit"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <tr class="gradeA">
                                            <td>11</td>
                                            <td>Gecko</td>
                                            <td>Camino 1.0</td>
                                            <td>OSX.2+</td>
                                            <td class="center">8</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center">4</td>
                                            <td class="center"></td>
                                            <td class="center">
                                                <button type="button" class="btn btn-xs btn-warning">
                                                    <i class="fa fa-edit"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div id="tab-2" class="tab-pane">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="panel-group" id="accordion">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h5 class="panel-title">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Información</a>
                                                    </h5>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse in">
                                                    <div class="panel-body">
                                                        <div class="form-group col-lg-4">
                                                            <label>Tipo Identificación</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Número Identificación</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Razón Social</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Dirección</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Teléfono</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Móvil</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Correo Electrónico</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Contacto</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Cargo</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Local</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Ciudad</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>País</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Cupo disponible</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Tipo de Cliente</label>
                                                            <select class="form-control input-sm">
                                                                <option>Seleccione</option>
                                                                <option>Comercial</option>
                                                                <option>Proyecto</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Plazo de Pago</label>
                                                            <input type="text" class="form-control input-sm">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h5 class="panel-title">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">Servicios</a>
                                                    </h5>
                                                </div>
                                                <div id="collapseTwo" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <div class="form-group col-lg-4">
                                                            <label>Preñez</label>
                                                            <div class="input-group m-b">
                                                                <span class="input-group-addon">$</span>
                                                                <input type="number" class="form-control">
                                                                <span class="input-group-addon">.00</span>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Embrión Fresco</label>
                                                            <div class="input-group m-b">
                                                                <span class="input-group-addon">$</span>
                                                                <input type="number" class="form-control">
                                                                <span class="input-group-addon">.00</span>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Embrión Congelado</label>
                                                            <div class="input-group m-b">
                                                                <span class="input-group-addon">$</span>
                                                                <input type="number" class="form-control">
                                                                <span class="input-group-addon">.00</span>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-lg-4">
                                                            <label>Embrión Vitrificado</label>
                                                            <div class="input-group m-b">
                                                                <span class="input-group-addon">$</span>
                                                                <input type="number" class="form-control">
                                                                <span class="input-group-addon">.00</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-lg-4">
                                        <button type="button" class="btn btn-w-m btn-primary">Guardar</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>