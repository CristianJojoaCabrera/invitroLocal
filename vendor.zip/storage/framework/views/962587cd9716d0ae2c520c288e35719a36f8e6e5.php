<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('css'); ?>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/plugins/steps/jquery.steps.css" rel="stylesheet">
    <link href="css/plugins/fullcalendar/fullcalendar.css" rel="stylesheet">
    <link href="css/plugins/fullcalendar/fullcalendar.print.css" rel='stylesheet' media='print'>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Nueva Orden de Producción</h2>
            <ol class="breadcrumb">
                <li>
                    <a href="index.html">Home</a>
                </li>
                <li>
                    Orden de Producción
                </li>
                <li class="active">
                    <strong>Nueva</strong>
                </li>
            </ol>
        </div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox">
                    <div class="ibox-title">
                        <h5>Nueva Orden de Producción</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li><a href="#">Config option 1</a>
                                </li>
                                <li><a href="#">Config option 2</a>
                                </li>
                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                        <h2>
                            Nueva Orden de Producción
                        </h2>
                        <form id="form" method="POST" action="<?php echo e(route('save_production_order')); ?>" class="wizard-big">
                            <?php echo e(csrf_field()); ?>

                            <h1>Cliente</h1>
                            <fieldset>
                                <h2>Información de Cliente</h2>
                                <div class="row">
                                    <div class="form-group col-lg-6">
                                        <label>Tipo de Cliente</label>
                                        <select class="form-control input-sm">
                                            <option value="">Seleccione</option>
                                            <option value="Comercial">Comercial</option>
                                            <option value="Proyecto">Proyecto</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Tipo de Identificación</label>
                                        <select type="text" class="form-control" name="cmbIdType">
                                            <option value="">Seleccione</option>
                                            <option value="CC">Cédula de ciudadanía</option>
                                            <option value="NT">Nit</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Identificación</label>
                                        <input type="text" class="form-control" name="txtIdNumber">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Razón Social</label>
                                        <input type="text" class="form-control" name="txtBussinessName">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Dirección</label>
                                        <input type="text" class="form-control" name="txtAddress">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Teléfono</label>
                                        <input type="text" class="form-control" name="txtPhone">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Móvil</label>
                                        <input type="text" class="form-control" name="txtCellphone">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Correo Electrónico</label>
                                        <input type="text" class="form-control" name="txtEmail">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Contacto</label>
                                        <input type="text" class="form-control" name="txtContact">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Cargo</label>
                                        <input type="text" class="form-control" name="txtPosition">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Local</label>
                                        <input type="text" class="form-control" name="">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Ciudad</label>
                                        <input type="text" class="form-control" name="txtCity">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>País</label>
                                        <input type="text" class="form-control" name="txtCountry">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Cupo Disponible</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                            </fieldset>
                            <h1>Servicios</h1>
                            <fieldset>
                                <h2>Servicios</h2>
                                <div class="row">
                                    <div class="form-group col-lg-6">
                                        <div class="i-checks"><label> <input type="checkbox" value=""> <i></i> Preñez </label></div>
                                        <div class="panel-group" id="accordion">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h5 class="panel-title">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Subservicios</a>
                                                    </h5>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Preñez</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Transporte</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Congelación</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Vitrificación</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Semen</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Genética</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <div class="i-checks"><label> <input type="checkbox" value=""> <i></i> Embrión Fresco </label></div>
                                        <div class="panel-group" id="accordion">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h5 class="panel-title">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">Subservicios</a>
                                                    </h5>
                                                </div>
                                                <div id="collapseTwo" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">OPU</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Embrión</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">TE</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Transporte</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Materiales</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Sémen</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Congelación</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Vitrificación</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Genética</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Otro</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <div class="i-checks"><label> <input type="checkbox" value=""> <i></i> Embrión Congelado </label></div>
                                        <div class="panel-group" id="accordion">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h5 class="panel-title">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">Subservicios</a>
                                                    </h5>
                                                </div>
                                                <div id="collapseThree" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">OPU</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Embrión</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">TE</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Transporte</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Materiales</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Sémen</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Genética</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Otro</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <div class="i-checks"><label> <input type="checkbox" value=""> <i></i> Embrión Vitrificado </label></div>
                                        <div class="panel-group" id="accordion">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h5 class="panel-title">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseFour">Subservicios</a>
                                                    </h5>
                                                </div>
                                                <div id="collapseFour" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">OPU</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Embrión</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">TE</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Transporte</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Materiales</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Sémen</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Genética</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Otro</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <div class="i-checks"><label> <input type="checkbox" value=""> <i></i> Servicio Técnico </label></div>
                                        <div class="panel-group" id="accordion">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h5 class="panel-title">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseFive">Subservicios</a>
                                                    </h5>
                                                </div>
                                                <div id="collapseFive" class="panel-collapse collapse">
                                                    <div class="panel-body">
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Selección</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Sincronización</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Dx. Gestación</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Aspiración</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">TE Embriones</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Sexaje fetal</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Evaluación Donadoras</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Desvitrificación</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Empaque embriones</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                        <div class="input-group m-b">
                                                            <span class="input-group-addon"><div class="i-checks"><input type="checkbox" value=""></div></span>
                                                            <span class="input-group-addon">Otro</span>
                                                            <span class="input-group-addon">$</span>
                                                            <input type="number" class="form-control">
                                                            <span class="input-group-addon">.00</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <h1>Agenda</h1>
                            <fieldset>
                                <h2>Agenda</h2>
                                <div class="row">
                                    <div id="calendar"></div>
                                </div>
                            </fieldset>
                            <h1>Finalizar</h1>
                            <fieldset>
                                <h2>Aprobar Orden de Producción</h2>
                                <input id="acceptTerms" name="acceptTerms" type="checkbox" class="required"> <label for="acceptTerms">¿Está seguro de generar la orden de producción?</label>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/plugins/fullcalendar/moment.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <!-- jQuery UI  -->
    <script src="<?php echo e(asset('js/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>

    <!-- Steps -->
    <script src="<?php echo e(asset('js/plugins/steps/jquery.steps.min.js')); ?>"></script>

    <!-- Jquery Validate -->
    <script src="<?php echo e(asset('js/plugins/validate/jquery.validate.min.js')); ?>"></script>

    <!-- iCheck -->
    <script src="<?php echo e(asset('js/plugins/iCheck/icheck.min.js')); ?>"></script>

    <!-- Full Calendar -->
    <script src="<?php echo e(asset('js/plugins/fullcalendar/fullcalendar.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $("#wizard").steps();
            $("#form").steps({
                bodyTag: "fieldset",
                onStepChanging: function (event, currentIndex, newIndex)
                {
                    // Always allow going backward even if the current step contains invalid fields!
                    if (currentIndex > newIndex)
                    {
                        return true;
                    }

                    // Forbid suppressing "Warning" step if the user is to young
                    if (newIndex === 3 && Number($("#age").val()) < 18)
                    {
                        return false;
                    }

                    var form = $(this);

                    // Clean up if user went backward before
                    if (currentIndex < newIndex)
                    {
                        // To remove error styles
                        $(".body:eq(" + newIndex + ") label.error", form).remove();
                        $(".body:eq(" + newIndex + ") .error", form).removeClass("error");
                    }

                    // Disable validation on fields that are disabled or hidden.
                    form.validate().settings.ignore = ":disabled,:hidden";

                    // Start validation; Prevent going forward if false
                    return form.valid();
                },
                onStepChanged: function (event, currentIndex, priorIndex)
                {
                    // Suppress (skip) "Warning" step if the user is old enough.
                    if (currentIndex === 2 && Number($("#age").val()) >= 18)
                    {
                        $(this).steps("next");
                    }

                    // Suppress (skip) "Warning" step if the user is old enough and wants to the previous step.
                    if (currentIndex === 2 && priorIndex === 3)
                    {
                        $(this).steps("previous");
                    }
                },
                onFinishing: function (event, currentIndex)
                {
                    var form = $(this);

                    // Disable validation on fields that are disabled.
                    // At this point it's recommended to do an overall check (mean ignoring only disabled fields)
                    form.validate().settings.ignore = ":disabled";

                    // Start validation; Prevent form submission if false
                    return form.valid();
                },
                onFinished: function (event, currentIndex)
                {
                    var form = $(this);

                    // Submit form input
                    form.submit();
                }
            }).validate({
                errorPlacement: function (error, element)
                {
                    element.before(error);
                },
                rules: {
                    confirm: {
                        equalTo: "#password"
                    }
                }
            });


            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });


            /* initialize the external events
             -----------------------------------------------------------------*/


            $('#external-events div.external-event').each(function() {

                // store data so the calendar knows to render an event upon drop
                $(this).data('event', {
                    title: $.trim($(this).text()), // use the element's text as the event title
                    stick: true // maintain when user navigates (see docs on the renderEvent method)
                });

                // make the event draggable using jQuery UI
                $(this).draggable({
                    zIndex: 1111999,
                    revert: true,      // will cause the event to go back to its
                    revertDuration: 0  //  original position after the drag
                });

            });


            /* initialize the calendar
             -----------------------------------------------------------------*/
            var date = new Date();
            var d = date.getDate();
            var m = date.getMonth();
            var y = date.getFullYear();

            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month,agendaWeek,agendaDay'
                },
                editable: true,
                droppable: true, // this allows things to be dropped onto the calendar
                drop: function() {
                    // is the "remove after drop" checkbox checked?
                    if ($('#drop-remove').is(':checked')) {
                        // if so, remove the element from the "Draggable Events" list
                        $(this).remove();
                    }
                },
                events: [
                    {
                        title: 'All Day Event',
                        start: new Date(y, m, 1)
                    },
                    {
                        title: 'Long Event',
                        start: new Date(y, m, d-5),
                        end: new Date(y, m, d-2)
                    },
                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: new Date(y, m, d-3, 16, 0),
                        allDay: false
                    },
                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: new Date(y, m, d+4, 16, 0),
                        allDay: false
                    },
                    {
                        title: 'Meeting',
                        start: new Date(y, m, d, 10, 30),
                        allDay: false
                    },
                    {
                        title: 'Lunch',
                        start: new Date(y, m, d, 12, 0),
                        end: new Date(y, m, d, 14, 0),
                        allDay: false
                    },
                    {
                        title: 'Birthday Party',
                        start: new Date(y, m, d+1, 19, 0),
                        end: new Date(y, m, d+1, 22, 30),
                        allDay: false
                    },
                    {
                        title: 'Click for Google',
                        start: new Date(y, m, 28),
                        end: new Date(y, m, 29),
                        url: 'http://google.com/'
                    }
                ]
            });


        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>