<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/fonts/font-awesome.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">