<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/plugins/iCheck/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/plugins/steps/jquery.steps.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/plugins/fullcalendar/fullcalendar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/plugins/fullcalendar/fullcalendar.print.css')); ?>" rel='stylesheet' media='print'>
    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2>Preorden de Producción</h2>
            <ol class="breadcrumb">
                <li>
                    <a href="<?php echo e(route('home')); ?>">Home</a>
                </li>
                <li>
                    Preorden de Producción
                </li>
                <li class="active">
                    <strong>Aprobar</strong>
                </li>
            </ol>
        </div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox">
                    <div class="ibox-title">
                        <h5>Preorden de Producción</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li><a href="#">Config option 1</a>
                                </li>
                                <li><a href="#">Config option 2</a>
                                </li>
                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                        <div class="row">
                            <form id="form" method="POST" action="<?php echo e(route('approve_production_order')); ?>" class="panel">
                                <div class="form-group">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="txtOrderId" value="<?php echo e($order->id); ?>">
                                    <p>Fecha <label id="lblOrderDate"><?php echo e($order->created_at); ?></label></p>
                                    <p>Número Identificación <label id="lblIdNumber"><?php echo e($order->client->identification_number); ?></label></p>
                                    <p>Razón Social <label id="lblBussinessName"><?php echo e($order->client->bussiness_name); ?></label></p>
                                    <p>Dirección <label id="lblAddress"><?php echo e($order->client->address); ?></label></p>
                                    <p>Teléfono <label id="lblPhone"><?php echo e($order->client->phone); ?></label></p>
                                    <p>Móvil <label id="lblCellphone"><?php echo e($order->client->cellphone); ?></label></p>
                                    <p>Correo Electrónico <label id="lblEmail"><?php echo e($order->client->email); ?></label></p>
                                    <p>Contacto <label id="lblContact"><?php echo e($order->client->contact); ?></label></p>
                                    <p>Cargo <label id="lblPosition"><?php echo e($order->client->position); ?></label></p>
                                    <p>Ciudad <label id="lblCity"><?php echo e($order->client->city); ?></label></p>
                                    <p>Departamento <label id="lblDepartment"><?php echo e($order->client->department); ?></label></p>
                                    <p>Cupo Disponible <label id="lblQuota"><?php echo e($order->client->quota); ?></label></p>
                                    <p>Locales</p>
                                    <table id="tblFinalLocals" class="table table-striped table-bordered table-hover dataTables-example" >
                                        <thead>
                                        <tr>
                                            <th>Nombre del local</th>
                                            <th>Ciudad</th>
                                            <th>Departamento</th>
                                            <th>Teléfono</th>
                                            <th>Correo</th>
                                            <th>Contacto</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($detail->local->name); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($detail->local->city); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($detail->local->department); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($detail->local->phone); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($detail->local->email); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($detail->local->contact); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <p>Servicios</p>
                                    <table id="tblFinalServices" class="table table-striped table-bordered table-hover dataTables-example" disabled>
                                        <thead>
                                        <tr>
                                            <th>Servicio</th>
                                            <th>Subservicio</th>
                                            <th>Valor</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $order->subservices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderSubservice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($orderSubservice->service->name); ?></td>
                                                <td><?php echo e($orderSubservice->subservice->name); ?></td>
                                                <td><?php echo e($orderSubservice->value); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-success" type="submit">Aprobar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/plugins/fullcalendar/moment.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <!-- jQuery UI  -->
    <script src="<?php echo e(asset('js/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>

    <!-- Steps -->
    <script src="<?php echo e(asset('js/plugins/steps/jquery.steps.min.js')); ?>"></script>

    <!-- Jquery Validate -->
    <script src="<?php echo e(asset('js/plugins/validate/jquery.validate.min.js')); ?>"></script>

    <!-- iCheck -->
    <script src="<?php echo e(asset('js/plugins/iCheck/icheck.min.js')); ?>"></script>

    <script>
        $(document).ready(function(){

            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });

        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>