@extends('layouts.home')

@section('title', 'Inicio')

@section('content')
    <div class="ibox float-e-margins">
        <div class="ibox-content" id="ibox-content">
            <div class="wrapper wrapper-content">
                <div class="row">
                    <img src="img/invitro_logo.png" class="img-fluid" alt="invitro_logo" style="width:100%">
                </div>
            </div>
        </div>
    </div>
@endsection